#!/usr/bin/env python3
"""Boot-only worker; run via autostart.py's installed hook, not as a watchdog."""
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent


def ready(c):
    paths = [c['binary'], c['web_home'] + '/index.html', c['wireguard_config'], c['data'] + '/settings.json']
    if not all(Path(p).is_file() for p in paths):
        return False
    if not all(shutil.which(p) for p in ('ip', 'wg', 'iptables', 'ip6tables', 'curl')):
        return False
    try:
        with socket.socket() as sock:
            sock.bind((c['lan_ip'], 0))
        result = subprocess.run(['curl', '-4fsS', '--noproxy', '*', '--connect-timeout', '3',
                                 '--max-time', '5', 'https://api.ipify.org'],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=7)
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def clear_old_marker(kit, current_boot):
    marker = BASE / 'active.json'
    if not marker.exists():
        return
    owned = json.loads(marker.read_text())
    if owned.get('boot_id') == current_boot:
        raise RuntimeError('State exists from this boot; inspect it manually instead of automatically restarting.')
    # Caller has already confirmed no namespace and no Transmission processes.
    # Never signal a saved PID after reboot: the PID may now belong to another process.
    if kit.RESOLV.exists():
        entries = list(kit.RESOLV.iterdir())
        if any(p.name != 'resolv.conf' or p.is_symlink() for p in entries):
            raise RuntimeError('Unexpected resolver directory contents; inspect manually.')
        for p in entries:
            p.unlink()
        kit.RESOLV.rmdir()
    os.replace(str(marker), str(BASE / 'active.previous-boot.json'))


def main():
    if os.geteuid() != 0:
        raise RuntimeError('Boot worker requires root.')
    os.umask(0o077)
    with (BASE / 'boot.log').open('a', buffering=1) as log:
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)
        print('\nBoot task:', time.strftime('%Y-%m-%d %H:%M:%S'), flush=True)
        with (BASE / 'config.json').open() as f:
            c = json.load(f)
        deadline = time.monotonic() + 600
        while not ready(c):
            if time.monotonic() >= deadline:
                raise RuntimeError('Timed out waiting for configured paths, tools, LAN address or internet.')
            time.sleep(10)
        spec = importlib.util.spec_from_file_location('qnap_vpn', str(BASE / 'qnap-vpn.py'))
        kit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(kit)
        kit.C = c
        for attr, command in [('IP','ip'),('WGTOOL','wg'),('IPT','iptables'),('IP6T','ip6tables'),('CURL','curl')]:
            setattr(kit, attr, shutil.which(command))
        with (BASE / 'control.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if kit.ns_exists():
                print('Namespace already exists; leaving it untouched. Verify with status.', flush=True)
                return
            if kit.processes():
                raise RuntimeError('Transmission is already running elsewhere. Normal QPKG must remain disabled.')
            current_boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
            clear_old_marker(kit, current_boot)
            kit.start()
        print('Boot launch finished. Verify UI and external torrent IP.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # main may have redirected stderr to persistent boot.log.
        print('BOOT ERROR: ' + str(error), file=sys.stderr, flush=True)
        sys.exit(1)
