#!/usr/bin/env python3
"""Install/remove this kit's QNAP autorun entry. HAL-based /dev/sd* boot devices only."""
import argparse
import datetime
import fcntl
import os
from pathlib import Path
import re
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parent
BEGIN = '# BEGIN QNAP-TRANSMISSION-VPN-KIT\n'
END = '# END QNAP-TRANSMISSION-VPN-KIT\n'


def block(base, python):
    return BEGIN + '''(
    trap '' HUP
    umask 077
    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
    export PATH
    mkdir /tmp/qtrns-autostart-once 2>/dev/null || exit 0
    exec >> /tmp/qtrns-autostart.log 2>&1
    date
    sleep 60
    count=0
    while [ "$count" -lt 90 ]; do
        if [ -x PYTHON_PATH ] && [ -r KIT_PATH/boot-start.py ] && [ -r KIT_PATH/config.json ]; then
            if PYTHON_PATH -c 'import fcntl, socket, json' >/dev/null 2>&1; then
                exec PYTHON_PATH -u KIT_PATH/boot-start.py
            fi
        fi
        count=$((count + 1))
        sleep 10
    done
    echo 'Timed out waiting for Python or the kit volume.'
) </dev/null >/dev/null 2>&1 &
'''.replace('PYTHON_PATH', shlex.quote(str(python))).replace('KIT_PATH', shlex.quote(str(base))) + END


def edit_text(text, replacement):
    if text.count(BEGIN) != text.count(END) or text.count(BEGIN) > 1:
        raise RuntimeError('Malformed managed block; refusing edit.')
    if BEGIN in text:
        a, b = text.index(BEGIN), text.index(END) + len(END)
        if text.index(END) < a:
            raise RuntimeError('Malformed managed block order.')
        return text[:a] + replacement + text[b:]
    if not replacement:
        return text
    if text.startswith('#!'):
        header, sep, rest = text.partition('\n')
        if header.strip() not in ('#!/bin/sh', '#!/bin/bash', '#!/usr/bin/sh', '#!/usr/bin/bash'):
            raise RuntimeError('Unrecognized autorun interpreter; refusing edit.')
        return header + '\n' + replacement + rest
    return '#!/bin/sh\n' + replacement + text


def call(args):
    return subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          universal_newlines=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['install', 'remove', 'status'])
    action = parser.parse_args().action
    if os.geteuid() != 0:
        raise RuntimeError('Use sudo -i first; root privileges are required.')
    os.umask(0o077)
    if action == 'install':
        for name in ('qnap-vpn.py', 'boot-start.py', 'config.json'):
            if not (BASE / name).is_file():
                raise RuntimeError('Missing ' + name + '; configure and test manual startup first.')
        for path in (BASE, BASE / 'qnap-vpn.py', BASE / 'boot-start.py', BASE / 'config.json'):
            info = path.stat()
            if info.st_uid != 0 or info.st_mode & 0o022:
                raise RuntimeError('Kit folder, launcher, boot script and config must be root-owned and not group/world writable. See guide.')
    with (BASE / 'autostart.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        device = call(['/sbin/hal_app', '--get_boot_pd', 'port_id=0']).stdout.strip()
        if not re.fullmatch(r'/dev/sd[a-z]+', device):
            raise RuntimeError('Unsupported boot-device layout: use model-specific QNAP instructions; no partition modified.')
        partition = device + '6'
        if not stat.S_ISBLK(os.stat(partition).st_mode):
            raise RuntimeError('Expected boot configuration partition is absent.')
        # Do not mount the same filesystem twice while the QTS UI or another tool edits it.
        for line in Path('/proc/mounts').read_text().splitlines():
            if os.path.realpath(line.split()[0]) == os.path.realpath(partition):
                raise RuntimeError('Boot partition already mounted. Close autorun viewer/unmount your earlier mount first.')
        mount = Path(tempfile.mkdtemp(prefix='qtrns-autorun-', dir='/tmp'))
        mounted = False
        try:
            call(['mount', '-o', 'ro' if action == 'status' else 'rw', partition, str(mount)])
            mounted = True
            target = mount / 'autorun.sh'
            if target.is_symlink():
                raise RuntimeError('autorun.sh is a symlink; refusing automatic edits.')
            text = target.read_text() if target.exists() else ''
            if action == 'status':
                print('Kit boot entry:', 'installed' if BEGIN in text else 'absent')
                print('Also check QTS Hardware > General: user-defined startup processes.')
                return
            replacement = block(BASE, Path(sys.executable).resolve()) if action == 'install' else ''
            updated = edit_text(text, replacement)
            if updated == text:
                print('No change needed.')
                return
            # Keep a persistent original backup; updates never overwrite it.
            backup = BASE / 'autorun.before-kit.sh'
            if not backup.exists():
                backup.write_text(text)
                os.chmod(str(backup), 0o600)
            candidate = mount / 'autorun.qtrns.new'
            candidate.write_text(updated)
            os.chmod(str(candidate), 0o700)
            try:
                call(['/bin/sh', '-n', str(candidate)])
                os.replace(str(candidate), str(target))
                os.sync()
            finally:
                if candidate.exists():
                    candidate.unlink()
            print('Boot entry {}. Running Transmission was not changed.'.format('installed' if action == 'install' else 'removed'))
            if action == 'install':
                print('Enable QTS Hardware > General > Run user-defined processes during startup.')
                print('Keep normal Transmission disabled in App Center. Verify after a planned reboot.')
        finally:
            if mounted:
                call(['umount', str(mount)])
            mount.rmdir()


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        print('ERROR: system command failed: ' + error.stderr.strip(), file=sys.stderr)
        sys.exit(1)
    except Exception as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        sys.exit(1)
