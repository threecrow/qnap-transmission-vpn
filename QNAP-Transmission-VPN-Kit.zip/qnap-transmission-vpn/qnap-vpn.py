#!/usr/bin/env python3
"""Manual QNAP Transmission/WireGuard lifecycle. Python 3.6+; run as root."""
import argparse
import configparser
import fcntl
import ipaddress
import json
import os
from pathlib import Path
import pwd
import select
import shutil
import signal
import socket
import socketserver
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
NS, WG, VH, VN = 'qtrns', 'qtrwg0', 'qtrhost0', 'qtrpeer0'
HOST, PEER = '172.31.191.1', '172.31.191.2'
NET = ipaddress.ip_network('172.31.191.0/30')
RESOLV = Path('/etc/netns') / NS


def run(args, check=True):
    return subprocess.run([str(a) for a in args], stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, universal_newlines=True, check=check)


def ns(*args):
    return run([IP, 'netns', 'exec', NS] + list(args))


def read_config():
    with (BASE / 'config.json').open() as f:
        return json.load(f)


def clean_env():
    env = os.environ.copy()
    for k in list(env):
        if k.lower().endswith('_proxy'):
            del env[k]
    return env


def settings_path():
    return Path(C['data']) / 'settings.json'


def pids():
    return [int(p) for p in run([IP, 'netns', 'pids', NS], False).stdout.split()]


def ns_exists():
    return any(line.split()[0] == NS for line in run([IP, 'netns', 'list']).stdout.splitlines() if line.split())


def processes():
    found = []
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            try:
                if (p / 'comm').read_text().strip().startswith('transmission'):
                    found.append(p.name)
            except OSError:
                pass
    return found


def detach(args, log):
    with open(log, 'ab', buffering=0) as output:
        return subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=output,
                                stderr=output, start_new_session=True, env=clean_env())


def stop():
    marker = BASE / 'active.json'
    if not marker.exists():
        raise RuntimeError('No ownership marker. Refusing to remove unowned network objects.')
    owned = json.loads(marker.read_text())
    if ns_exists():
        inode = os.stat('/var/run/netns/' + NS).st_ino
        if inode != owned['inode']:
            raise RuntimeError('Namespace identity changed; refusing cleanup.')
        for pid in pids():
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        for _ in range(30):
            if not pids():
                break
            time.sleep(1)
        if pids():
            raise RuntimeError('Processes still exiting; wait and run stop again. No force kill performed.')
        run([IP, 'netns', 'del', NS])
    # Proxy identity is checked using its command line before signaling.
    proxy = owned.get('proxy_pid')
    if proxy:
        try:
            cmd = Path('/proc/{}/cmdline'.format(proxy)).read_bytes().split(b'\0')
            if str(BASE / 'qnap-vpn.py').encode() in cmd and b'_proxy' in cmd:
                os.kill(proxy, signal.SIGTERM)
        except (OSError, ProcessLookupError):
            pass
    if RESOLV.exists():
        if (RESOLV / 'resolv.conf').exists():
            (RESOLV / 'resolv.conf').unlink()
        RESOLV.rmdir()
    marker.unlink()
    print('Stopped. Normal QPKG has NOT been started. Settings backup retained.')


def start():
    if (BASE / 'active.json').exists() or ns_exists():
        raise RuntimeError('Existing setup detected. Run status/stop first.')
    if processes():
        raise RuntimeError('Transmission already running: ' + ', '.join(processes()) + '. Stop/disable its normal QPKG first.')
    if RESOLV.exists():
        raise RuntimeError('Reserved resolver directory exists: ' + str(RESOLV))
    for name in (WG, VH, VN):
        if run([IP, 'link', 'show', name], False).returncode == 0:
            raise RuntimeError('Reserved interface exists: ' + name)
    routes = run([IP, '-4', 'route', 'show', 'table', 'all']).stdout
    for line in routes.splitlines():
        word = line.split()[0]
        try:
            network = ipaddress.ip_network(word, strict=False)
            if network.prefixlen and network.overlaps(NET):
                raise RuntimeError('Private link subnet overlaps a host route: ' + line)
        except ValueError:
            pass
    bind_ip = str(ipaddress.IPv4Address(C['lan_ip']))
    if bind_ip in ('0.0.0.0', HOST, PEER):
        raise RuntimeError('Set lan_ip to this NAS LAN address.')
    with socket.socket() as test:
        test.bind((bind_ip, int(C['web_port'])))
    for f in (C['binary'], C['web_home'] + '/index.html', str(settings_path()), C['wireguard_config']):
        if not Path(f).is_file():
            raise RuntimeError('Missing file: ' + f)
    account = pwd.getpwnam(C['run_as'])
    if account.pw_uid == 0 and not C.get('allow_root', False):
        raise RuntimeError('Root execution needs explicit allow_root=true; prefer a dedicated account.')
    cfg = configparser.ConfigParser(interpolation=None, strict=True)
    cfg.optionxform = str
    cfg.read(C['wireguard_config'])
    if set(cfg.sections()) != {'Interface', 'Peer'}:
        raise RuntimeError('Requires one Interface and one Peer; use a standard single-peer Proton config.')
    addresses = [x.strip() for x in cfg['Interface']['Address'].split(',')]
    address = next((x for x in addresses if ipaddress.ip_interface(x).version == 4), None)
    dns = [x.strip() for x in cfg['Interface']['DNS'].split(',')]
    dns = [str(ipaddress.ip_address(x)) for x in dns if ipaddress.ip_address(x).version == 4]
    if not address or not dns:
        raise RuntimeError('Requires IPv4 Address and IPv4 DNS in WireGuard config.')
    if any(ipaddress.ip_address(x) in NET or ipaddress.ip_address(x).is_loopback for x in dns):
        raise RuntimeError('DNS must be reachable through the VPN, not the private web link.')
    allowed = [x.strip() for x in cfg['Peer']['AllowedIPs'].split(',')]
    if '0.0.0.0/0' not in allowed:
        raise RuntimeError('Peer must allow 0.0.0.0/0.')
    # No wg-quick, shell hooks, or filename-derived interface names.
    wg_lines = ['[Interface]', 'PrivateKey = ' + cfg['Interface']['PrivateKey'], '[Peer]']
    for key in ('PublicKey', 'PresharedKey', 'Endpoint', 'PersistentKeepalive'):
        if key in cfg['Peer']:
            wg_lines.append(key + ' = ' + cfg['Peer'][key])
    if 'Endpoint' not in cfg['Peer']:
        raise RuntimeError('Missing WireGuard Endpoint.')
    wg_lines.append('AllowedIPs = 0.0.0.0/0')
    settings = json.loads(settings_path().read_text())
    def get(key, default=None):
        return settings.get(key, settings.get(key.replace('-', '_'), default))
    if not get('rpc-authentication-required', False) or not get('rpc-password') or not get('rpc-username'):
        raise RuntimeError('Configure Transmission RPC username/password authentication before using this kit.')
    backup = BASE / 'settings.original.json'
    if not backup.exists():
        shutil.copy2(str(settings_path()), str(backup))
        os.chmod(str(backup), 0o600)
    def put(key, value):
        actual = key.replace('-', '_') if key.replace('-', '_') in settings else key
        settings[actual] = value
    for key, value in {'rpc-enabled': True, 'rpc-bind-address': '0.0.0.0', 'rpc-port': 9091,
                       'rpc-url': '/transmission/', 'rpc-whitelist-enabled': True,
                       'rpc-whitelist': '127.0.0.1,' + HOST,
                       'announce-ip-enabled': False, 'port-forwarding-enabled': False}.items():
        put(key, value)
    # Keep host checking enabled; numeric LAN URLs are used by this guide.
    put('rpc-host-whitelist-enabled', True)
    put('rpc-host-whitelist', bind_ip + ',localhost')
    settings_path().write_text(json.dumps(settings, indent=4) + '\n')
    private = BASE / 'wireguard.runtime.conf'
    private.write_text('\n'.join(wg_lines) + '\n')
    os.chmod(str(private), 0o600)
    created_wg = False
    try:
        run([IP, 'netns', 'add', NS])
        owned = {'inode': os.stat('/var/run/netns/' + NS).st_ino}
        (BASE / 'active.json').write_text(json.dumps(owned))
        RESOLV.mkdir(parents=True)
        (RESOLV / 'resolv.conf').write_text(''.join('nameserver ' + x + '\n' for x in dns))
        run([IP, 'link', 'add', WG, 'type', 'wireguard'])
        created_wg = True
        run([IP, 'link', 'set', WG, 'netns', NS])
        ns(WGTOOL, 'setconf', WG, str(private))
        run([IP, '-n', NS, 'addr', 'add', address, 'dev', WG])
        run([IP, '-n', NS, 'link', 'set', WG, 'mtu', str(C.get('mtu', 1420)), 'up'])
        run([IP, '-n', NS, 'link', 'set', 'lo', 'up'])
        run([IP, 'link', 'add', VH, 'type', 'veth', 'peer', 'name', VN])
        run([IP, 'link', 'set', VN, 'netns', NS])
        run([IP, 'addr', 'add', HOST + '/30', 'dev', VH])
        run([IP, 'link', 'set', VH, 'up'])
        run([IP, '-n', NS, 'addr', 'add', PEER + '/30', 'dev', VN])
        run([IP, '-n', NS, 'link', 'set', VN, 'up'])
        # Policies apply ONLY inside this namespace; no NAS firewall flushing or NAT.
        for table in (IPT, IP6T):
            for chain in ('INPUT', 'OUTPUT', 'FORWARD'):
                ns(table, '-P', chain, 'DROP')
            ns(table, '-A', 'INPUT', '-i', 'lo', '-j', 'ACCEPT')
            ns(table, '-A', 'OUTPUT', '-o', 'lo', '-j', 'ACCEPT')
        ns(IPT, '-A', 'INPUT', '-i', WG, '-j', 'ACCEPT')
        ns(IPT, '-A', 'OUTPUT', '-o', WG, '-j', 'ACCEPT')
        ns(IPT, '-A', 'INPUT', '-i', VN, '-s', HOST, '-p', 'tcp', '--dport', '9091', '-j', 'ACCEPT')
        ns(IPT, '-A', 'OUTPUT', '-o', VN, '-d', HOST, '-p', 'tcp', '--sport', '9091',
           '-m', 'conntrack', '--ctstate', 'ESTABLISHED', '-j', 'ACCEPT')
        run([IP, '-n', NS, 'route', 'add', 'default', 'dev', WG])
        print('Namespace external IPv4:', ns(CURL, '-4fsS', '--noproxy', '*', '--max-time', '20',
                                              'https://api.ipify.org').stdout.strip())
        tr = detach([IP, 'netns', 'exec', NS, sys.executable, str(BASE / 'qnap-vpn.py'), '_daemon'], BASE / 'transmission.log')
        for _ in range(20):
            if tr.poll() is not None:
                raise RuntimeError('Transmission exited; inspect transmission.log.')
            try:
                with socket.create_connection((PEER, 9091), timeout=1):
                    break
            except OSError:
                time.sleep(1)
        else:
            raise RuntimeError('Transmission RPC did not start; inspect log and permissions.')
        proxy = detach([sys.executable, str(BASE / 'qnap-vpn.py'), '_proxy'], BASE / 'proxy.log')
        owned['proxy_pid'] = proxy.pid
        (BASE / 'active.json').write_text(json.dumps(owned))
        time.sleep(1)
        if proxy.poll() is not None:
            raise RuntimeError('Proxy exited; inspect proxy.log.')
        print('Started: http://{}:{}/transmission/web/'.format(bind_ip, C['web_port']))
        print('Run the external torrent IP test before normal use. Reboot autostart is NOT installed.')
    except Exception:
        if (BASE / 'active.json').exists():
            stop()
        if created_wg:
            run([IP, 'link', 'del', WG], False)
        run([IP, 'link', 'del', VH], False)
        raise
    finally:
        if private.exists():
            private.unlink()


def daemon():
    account = pwd.getpwnam(C['run_as'])
    os.initgroups(account.pw_name, account.pw_gid)
    os.setgid(account.pw_gid)
    os.setuid(account.pw_uid)
    os.chdir(C['data'])
    env = clean_env()
    env['TRANSMISSION_WEB_HOME'] = C['web_home']
    env['HOME'] = account.pw_dir
    os.execve(C['binary'], [C['binary'], '-f', '--config-dir', C['data']], env)


class Relay(socketserver.BaseRequestHandler):
    def handle(self):
        try:
            with socket.create_connection((PEER, 9091), timeout=10) as upstream:
                upstream.settimeout(None)
                sockets = [self.request, upstream]
                while sockets:
                    ready, _, _ = select.select(sockets, [], [], 300)
                    if not ready:
                        return
                    for source in ready:
                        other = upstream if source is self.request else self.request
                        data = source.recv(65536)
                        if data:
                            other.sendall(data)
                        else:
                            other.shutdown(socket.SHUT_WR)
                            sockets.remove(source)
        except OSError:
            pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def status():
    print('Transmission PIDs:', ', '.join(processes()) or '(none)')
    if not ns_exists():
        print('Namespace absent.')
        return
    print('Namespace PIDs:', pids())
    print(run([IP, '-n', NS, 'route']).stdout)
    print(ns(WGTOOL, 'show', WG).stdout)
    for pid in processes():
        print('PID', pid, 'network namespace:', os.readlink('/proc/' + pid + '/ns/net'))
    print('Expected:', ns('readlink', '/proc/self/ns/net').stdout.strip())


def drop_test():
    if not (BASE / 'active.json').exists() or not ns_exists():
        raise RuntimeError('Start this kit first.')
    probe = [CURL, '-4fsS', '--noproxy', '*', '--connect-timeout', '4', '--max-time', '8', 'https://1.1.1.1/cdn-cgi/trace']
    ns(*probe)  # Require a working baseline so endpoint failures cannot masquerade as protection.
    print('Baseline succeeded. Disabling ONLY namespace WireGuard for an 8-second probe.')
    try:
        run([IP, '-n', NS, 'link', 'set', WG, 'down'])
        result = run([IP, 'netns', 'exec', NS] + probe, False)
        if result.returncode == 0:
            raise RuntimeError('FAIL: external connection succeeded with tunnel down.')
        print('PASS for this IPv4 probe: connection failed with tunnel down.')
    finally:
        run([IP, '-n', NS, 'link', 'set', WG, 'up'])
    print('Tunnel restored. Repeat external torrent test; this is not exhaustive leak certification.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['start', 'stop', 'status', 'drop-test', 'restore-settings', '_daemon', '_proxy'])
    args = parser.parse_args()
    os.umask(0o077)
    C = read_config()
    IP = shutil.which('ip') or '/bin/ip'
    WGTOOL = shutil.which('wg') or '/usr/bin/wg'
    IPT = shutil.which('iptables') or '/sbin/iptables'
    IP6T = shutil.which('ip6tables') or '/sbin/ip6tables'
    CURL = shutil.which('curl') or '/usr/bin/curl'
    try:
        if os.geteuid() != 0:
            raise RuntimeError('Run as UID 0 via your NAS administrator SSH session.')
        if args.action == '_daemon':
            daemon()
        elif args.action == '_proxy':
            with Server((C['lan_ip'], int(C['web_port'])), Relay) as server:
                server.serve_forever()
        else:
            with (BASE / 'control.lock').open('w') as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                if args.action == 'restore-settings':
                    if processes() or ns_exists():
                        raise RuntimeError('Stop Transmission and this namespace before restoring settings.')
                    # Write in place to retain current file ownership and permissions.
                    settings_path().write_bytes((BASE / 'settings.original.json').read_bytes())
                    print('Original settings restored. Normal QPKG remains stopped.')
                else:
                    {'start': start, 'stop': stop, 'status': status, 'drop-test': drop_test}[args.action]()
    except Exception as error:
        # Do not echo command arguments or config content containing VPN keys.
        if isinstance(error, subprocess.CalledProcessError):
            print('ERROR: command failed (exit {}). Check prerequisites and logs.'.format(error.returncode), file=sys.stderr)
        else:
            print('ERROR:', str(error), file=sys.stderr)
        sys.exit(1)
